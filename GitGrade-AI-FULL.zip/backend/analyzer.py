import os
from git import Repo

def clone_repo(url):
    path = "repo"
    if not os.path.exists(path):
        Repo.clone_from(url, path)
    return path

def analyze_structure(path):
    count = 0
    for _, _, files in os.walk(path):
        count += len(files)
    return count

def check_readme(path):
    return os.path.exists(os.path.join(path, "README.md"))

def check_tests(path):
    return "tests" in os.listdir(path)

def check_ci_cd(path):
    return ".github" in os.listdir(path)
