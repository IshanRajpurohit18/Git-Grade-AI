def calculate_score(files, readme, tests, commits, complexity):
    score = min(files * 0.5, 15)
    score += 15 if readme else 0
    score += 15 if tests else 0
    score += min(commits * 1.5, 20)
    score += 20 if complexity < 10 else 10
    score += 15
    return min(int(score), 100)
