def generate_ai_feedback(score, readme, tests, commits):
    if score >= 80:
        summary = "Strong, industry-ready repository with clean practices."
    elif score >= 50:
        summary = "Good project but needs better documentation and testing."
    else:
        summary = "Early-stage project needing structural improvements."

    roadmap = []
    if not readme:
        roadmap.append("Add a detailed README.")
    if not tests:
        roadmap.append("Write unit tests.")
    if commits < 10:
        roadmap.append("Improve commit consistency.")

    roadmap.append("Add CI/CD with GitHub Actions.")
    roadmap.append("Refactor complex code.")

    return summary, roadmap
