from fastapi import FastAPI
from pydantic import BaseModel
from analyzer import clone_repo, analyze_structure, check_readme, check_tests, check_ci_cd
from scorer import calculate_score
from ai_engine import generate_ai_feedback
from git import Repo

app = FastAPI()

class RepoInput(BaseModel):
    repo_url: str

@app.post("/analyze")
def analyze_repo(data: RepoInput):
    path = clone_repo(data.repo_url)

    files = analyze_structure(path)
    readme = check_readme(path)
    tests = check_tests(path)
    ci = check_ci_cd(path)

    repo = Repo(path)
    commits = len(list(repo.iter_commits()))
    complexity = 12

    score = calculate_score(files, readme, tests, commits, complexity)
    summary, roadmap = generate_ai_feedback(score, readme, tests, commits)

    return {"score": score, "summary": summary, "roadmap": roadmap}
