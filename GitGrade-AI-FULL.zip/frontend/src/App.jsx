import RepoForm from "./components/RepoForm";
import ResultCard from "./components/ResultCard";
import { useState } from "react";

function App() {
  const [result, setResult] = useState(null);

  return (
    <div style={{ padding: "40px", fontFamily: "Arial" }}>
      <h1>GitGrade AI</h1>
      <RepoForm setResult={setResult} />
      {result && <ResultCard result={result} />}
    </div>
  );
}

export default App;
