export default function Roadmap({ roadmap }) {
  return (
    <ul>
      {roadmap.map((r, i) => <li key={i}>{r}</li>)}
    </ul>
  );
}
