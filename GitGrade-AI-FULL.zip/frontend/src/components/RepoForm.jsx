import { useState } from "react";
import axios from "axios";

export default function RepoForm({ setResult }) {
  const [url, setUrl] = useState("");

  const analyze = async () => {
    const res = await axios.post("http://localhost:8000/analyze", {
      repo_url: url
    });
    setResult(res.data);
  };

  return (
    <div>
      <input placeholder="GitHub Repo URL" onChange={e => setUrl(e.target.value)} />
      <button onClick={analyze}>Analyze</button>
    </div>
  );
}
