import Roadmap from "./Roadmap";

export default function ResultCard({ result }) {
  return (
    <div>
      <h2>Score: {result.score}/100</h2>
      <p>{result.summary}</p>
      <Roadmap roadmap={result.roadmap} />
    </div>
  );
}
