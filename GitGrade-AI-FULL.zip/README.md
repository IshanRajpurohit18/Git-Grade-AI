# GitGrade AI

Full-stack AI-based GitHub Repository Evaluator
